import android.app.Activity;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.content.Intent;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import assistant.genuinecoder.s_assistant.main.AppBase;
public class facebook extends AppCompatActivity {
    ListView listView;
    ArrayAdapter adapter;
    ArrayList items;
    ArrayList contents;
    Activity activity = this;

    public void openFacebook(View v){
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);
        String webPage = "https://www.facebook.com";
        Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(webPage));
        startActivity(intent);

    }
}
