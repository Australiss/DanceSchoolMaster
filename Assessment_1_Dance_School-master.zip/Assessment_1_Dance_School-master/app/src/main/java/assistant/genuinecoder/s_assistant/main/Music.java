package assistant.genuinecoder.s_assistant.main;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import assistant.genuinecoder.s_assistant.R;

public class Music extends AppCompatActivity {

    public MediaPlayer mPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);
        mPlayer = MediaPlayer.create(getApplicationContext(),R.raw.thillana);
    }
    public void playPause (View v) {
        if(mPlayer.isPlaying()){
            mPlayer.pause();
        } else {
            mPlayer.start();
        }
    }
}
